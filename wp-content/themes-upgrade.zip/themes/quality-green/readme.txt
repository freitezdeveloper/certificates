Quality Green is the child version of Quality theme.


===== Change Log =========
= 1.2.6 =
1. Update styling.
= 1.2.5 =
1. Strings update.
= 1.2.4 =
1. Strings update.
= 1.2.3 =
1. Updated Theme URI & Author URI
= 1.2.2 =
1. Remove duplicate fullwidth page.
= 1.2.1 =
1. Update pot file.
= 1.2 =
1. Change Screenshot Image.
= 1.1 =
1. Fixed Styling issue.
= 1.0.1 =
1 Added Theme URI
= 1.0 =
1. Added template Blog Full width
2. Added template Page Full Width
3. Added template fullwidth page

= 0.1 =
released