<?php if ( is_active_sidebar( 'sidebar-primary' ) ): ?>
	<div class="col-md-4 col-sm-4 col-xs-12">
		<div class="sidebar" >
		<?php dynamic_sidebar( 'sidebar-primary' );	 ?>
		</div>
	</div>
<?php endif; ?> 
<!-- Right sidebar ---->